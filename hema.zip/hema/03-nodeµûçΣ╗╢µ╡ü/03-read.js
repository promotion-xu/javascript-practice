const fs = require("fs");
fs.readFile("test.mtl", "utf8", function (err, data) {
  //   console.log(data);
  let theFile = data.toString().split("\n").slice(4);
  theFile.forEach((item) => {
    const arr = item.split(" ");
    const key = arr[0];
    const value = arr[1];
    let obj = {};
    obj[key] = value;
    console.log(obj);
  });
});
